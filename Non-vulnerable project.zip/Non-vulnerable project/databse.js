const mysql = require('mysql2');
const dotenv = require('dotenv');
const bcrypt = require('bcrypt');
dotenv.config();

const pool = mysql.createPool({
    host: process.env.MYSQL_HOST,
    user:process.env.MYSQL_USER,
    port:process.env.MYSQL_PORT,
    password:process.env.MYSQL_PASSWORD,
    database:process.env.MYSQL_DATABASE
}).promise()


const { PASSWORDS_HISTORY} = process.env;

async function getNotes(){
    try {
        const result = await pool.query("SELECT * FROM users");
        const rows = result[0];
        return rows;
    }  catch(err){
        console.log(err);
    }
}

async function getId(id){
try {
    const result = await pool.query("" +
        "SELECT * " +
        "FROM users" +
        " WHERE idUsers = ?", id);
    const rows = result[0];
    return rows[0];
}
    catch(err){
    console.log(err);
    }
}
async function getLastColumnValue() {
    try {
        const query = `SELECT idUsers FROM users ORDER BY idUsers DESC LIMIT 1`;
        const result = await pool.query(query);
        console.log("result", result);
        const rows = result[0];
        if (rows.length > 0) {
            return rows[0]['idUsers'];
        } else {
            return (`No rows found in users`);
        }
    } catch (err) {
        console.error('Error fetching last column value:', err);
        return err;
    }
}

async function createUser(username, email, password){
     try {
         const hashedPassword= await bcrypt.hash(password, 10);
         const lastId = await getLastColumnValue();
         const newId = lastId + 1;
         const latestPasswords = [];
         latestPasswords.push({ hashedPassword });

         // Convert the array to a JSON string
         const jsonLatestPasswords = JSON.stringify(latestPasswords);
         console.log("jsonPasswordhashedPassword", jsonLatestPasswords);
         console.log("latestPasswords", latestPasswords);
         console.log("lastId", lastId);
         const result = await pool.query("" +
         "INSERT INTO users (idUsers,userName, userEmail, userPassword,userRole,latestPasswords) " +
         "VALUES (?,?,?,?,?,?)", [newId,username, email, hashedPassword,'user',jsonLatestPasswords]);
         console.log(result);
         console.log("User created");
        return result;
    } catch (err) {
        console.log(err);
    }
}

async function findUserByUsernameOrEmail(username, email) {
    try {
        const query = `SELECT idUsers, COUNT(*) AS userCount FROM users WHERE userName = ? OR userEmail = ? GROUP BY idUsers`;
        const result = await pool.query(query, [username, email]);
        const userCount = result[0].length; // Use the length of the result array
        console.log("userCount", userCount);
        if (userCount > 0) {
            const idUsers = result[0][0].idUsers; // Access idUsers from the first row
            console.log("idUsers", idUsers);
            return idUsers;
        } else {
            return false; // Return false if user not found
        }
    } catch (err) {
        console.error('Error finding user by username or email:', err);
    }
}

async function passwordValidation(password,id) { //check current password of the userID what the sent password
    try {
        const query = `SELECT userPassword FROM users WHERE idUsers = ?`;
        const result = await pool.query(query, [id]);
        if (result[0].length > 0) {
            const storedPassword = result[0][0].userPassword;
            const isMatch = await bcrypt.compare(password, storedPassword);
            console.log("User password validation : ", isMatch);
            return isMatch; // return true if passwords match, else false
        } else {
            return false; // User ID not found
        }
    } catch (err) {
        console.error('Error finding user by ID:', err);
        throw err;
    }
}
async function getPasswordHistory(idUsers) {
    try {
        const query = `SELECT latestPasswords FROM users WHERE idUsers = ?`;
        const result = await pool.query(query, idUsers);
        const rows = result[0];
        if (rows.length > 0) {
            const latestPasswords = rows[0].latestPasswords;
            console.log("latestPasswords----------", latestPasswords);
            if (latestPasswords === null) {
                console.log(`No password history found for user with id ${idUsers}`);
                return [];
            } else {
                return latestPasswords;
            }
        } else {
            console.log(`No rows found in users`);
            return false;
        }
    } catch (err) {
        console.error('Error fetching password history:', err);
        return err;
    }
}
async function getUserRoleById(idUsers) {
    try {
        const query = `SELECT userRole FROM users WHERE idUsers = ?`;
        const result = await pool.query(query, idUsers);
        const rows = result[0];

        if (rows.length > 0) {
            return rows[0].userRole;
        } else {
            console.log(`No user found with id ${idUsers}`);
            return false;
        }
    } catch (err) {
        console.error('Error fetching user role:', err);
        return err;
    }
}
async function updateUserPassword(id,password){
    try {
        // Hash the new password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Update the user's password in the database
        const updateQuery = `UPDATE users SET userPassword = ? WHERE idUsers = ?`;
        const updateResult = await pool.query(updateQuery, [hashedPassword, id]);

        console.log("Password updated successfully");
        return updateResult;
    } catch (err) {
        console.error('Error updating password:', err);
        throw err;
    }
}
async function updatePasswordHistory(id,password){
    try {
        // Fetch the current password history
        const currentPasswordHistoryQuery = `SELECT latestPasswords FROM users WHERE idUsers = ?`;
        const currentPasswordHistoryResult = await pool.query(currentPasswordHistoryQuery, id);

        const latestPasswordsArray = currentPasswordHistoryResult[0][0].latestPasswords || [];

        // Hash the new password
        const hashedPass = await bcrypt.hash(password, 10);

        // Add the new hashed password to the array
        latestPasswordsArray.push({ hashedPassword: hashedPass });

        // Keep only the latest 3 passwords in the history
        const passwordHistoryLimit = process.env.PASSWORDS_HISTORY || 3;
        const updatedPasswordHistory = latestPasswordsArray.slice(-passwordHistoryLimit);

        // Update the latestPasswords column with the updated array
        const updateQuery = `UPDATE users SET latestPasswords = ? WHERE idUsers = ?`;
        const updateResult = await pool.query(updateQuery, [JSON.stringify(updatedPasswordHistory), id]);

        console.log("Hashed Passwords:", updatedPasswordHistory);
        console.log(updateResult);
        console.log("Password history updated");
        return updateResult;
    } catch (err) {
        console.error('Error updating password history:', err);
        throw err;
    }
}


module.exports = { getId, createUser, getNotes ,getLastColumnValue,updateUserPassword
    ,findUserByUsernameOrEmail,getPasswordHistory,updatePasswordHistory,passwordValidation,getUserRoleById};

