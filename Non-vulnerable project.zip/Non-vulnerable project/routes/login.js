const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const db = require("../databse");
const dotenv = require('dotenv');
const jwt = require("jsonwebtoken");

const {
    REQUIRE_SYMBOLS,
    REQUIRE_LOWERCASE,
    REQUIRE_UPPERCASE,
    REQUIRE_DIGITS,
    MIN_LENGTH,
    MAX_LENGTH,
    PASSWORDS_HISTORY,
    LOGIN_RETRIES,
    JWT_SECRET,
    JWTEXPIRESIN

} = process.env;

router.get('/', (req, res) => {
    res.sendFile(__dirname + '/login.html');
});

router.post('/', async (req, res) => {
    // Handle login logic
    const { username, password } = req.body;

    //checking users existence
    const isUser = await db.findUserByUsernameOrEmail(username, null);

    console.log("User finding result : "+isUser);
    if(!isUser) {
        console.log("User or password are wrong");
        var userExistsMessage = ("Username or password are incorrect");
        return res.status(400).send(`<script>alert('${userExistsMessage}'); window.location.href='/login'</script>`);
    }

    //checking password
    const storedPassword = await db.passwordValidation(password, isUser);
    if(!storedPassword) {
        console.log("User or password are wrong");
        var userExistsMessage = ("Username or password are incorrect");
        return res.status(400).send(`<script>alert('${userExistsMessage}'); window.location.href='/login'</script>`);
    }
    console.log("password is valid");
    console.log("isUser.idUsers : "+isUser);
    console.log(storedPassword);
    console.log("need to apply login");
    const role = await db.getUserRoleById(isUser);
    console.log("role of login: "+role);
    const token = jwt.sign({ username: username , role:role}, JWT_SECRET,{expiresIn: JWTEXPIRESIN});
    const creationMessage = ("User login successfully");
    res.cookie('jwt', token, { httpOnly: true, maxAge: 5 * 60 * 1000 });
    return res.status(200).send(`<script>alert('${creationMessage}'); window.location.href='/'</script>`);

});

module.exports = router;
