const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const db = require("../databse");
const dotenv = require('dotenv');
const jwt = require("jsonwebtoken");


router.get('/', (req, res) => {
    const { jwt } = req.cookies;
    console.log(jwt);
    if(!req.cookies.jwt) {
        var failLogout = "Logout failed - please login to signout";
        return res.clearCookie('jwt').send(`<script>alert('${failLogout}'); window.location.href='/'</script>`);
    }

    var successLogout = "Logout successful";
    return res.clearCookie('jwt').send(`<script>alert('${successLogout}'); window.location.href='/'</script>`);


});

router.post('/', async (req, res) => {

});

module.exports = router;