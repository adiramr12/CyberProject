const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const db = require("../databse");
const dotenv = require('dotenv');
const auth =require("../basicAuth");
const jwt = require("jsonwebtoken");

const {
    REQUIRE_SYMBOLS,
    REQUIRE_LOWERCASE,
    REQUIRE_UPPERCASE,
    REQUIRE_DIGITS,
    MIN_LENGTH,
    MAX_LENGTH,
    PASSWORDS_HISTORY,
    LOGIN_RETRIES
} = process.env;


router.get('/',auth.authUser,(req, res) => {
    res.sendFile(__dirname + '/resetpassword.html');
});

router.post('/', async (req, res) => {
    const { username, newpassword ,oldpassword} = req.body;
    const password = newpassword;
    //checking users existence
    const jwtCookie = req.cookies.jwt;
    const decodedToken = jwt.decode(jwtCookie);
    const loginUsername = decodedToken.username;
    console.log("User matching to logged one ");
    if(!(username ===loginUsername)) {
        console.log("User was not found");
        var userExistsMessage = ("You can only reset your own password - please add YOUR username");
        return res.status(400).send(`<script>alert('${userExistsMessage}'); window.location.href='/resetpassword'</script>`);
    }

    const isUser = await db.findUserByUsernameOrEmail(username, null);
    console.log("User finding result : "+isUser);
    if(!isUser) {
        console.log("User was not found");
        var userExistsMessage = ("Username or email are incorrect");
        return res.status(400).send(`<script>alert('${userExistsMessage}'); window.location.href='/resetpassword'</script>`);
    }

    // Password Validation
    const isPasswordValid = checkPasswordRequirements(password);
    if(!isPasswordValid) {
        var requirementsMessage=("Password should meet the following requirements:\\n"+
            "Include at least one symbol, one lowercase, one uppercase, one digit and length between " + `${MIN_LENGTH} and ${MAX_LENGTH}` )
        return res.status(400).send(`<script>alert('${requirementsMessage}'); window.location.href='/resetpassword'</script>`);
    }


    console.log("password is valid");
    console.log(isPasswordValid);


    // Check if the password is the current one
    const checkingPassowrds= await db.passwordValidation(oldpassword, isUser);
    console.log("checkingPassowrds : "+checkingPassowrds);
    if(checkingPassowrds===false) {
        var passwordHistoryMessage=("User or password are wrong");
        console.log("Reset password was failed due to wrong password");
        return res.status(400).send(`<script>alert('${passwordHistoryMessage}'); window.location.href='/resetpassword'</script>`);
    }
    // Check if the new password is not in the user's password history
    const passwordHistory = await db.getPasswordHistory(isUser);
    console.log("isPasswordNew : "+JSON.stringify(passwordHistory));
    if(passwordHistory[0]===null)
    {
        console.log("No reset password history");

    }
    else {
        console.log("passwordHistory is not empty");
         const isPasswordInHistory = [];
        const latestPasswordsArray = passwordHistory;
        console.log("passwordHistory[0]passwordHistory[0]passwordHistory[0]",passwordHistory[0])
        console.log("passwordHistory : "+latestPasswordsArray);
        for (const entry of passwordHistory) {
            const oldHashedPassword = entry.hashedPassword;
            const isMatch = await bcrypt.compare(password, oldHashedPassword);
            console.log("password",password);
            console.log("oldHashedPassword",oldHashedPassword);
            isPasswordInHistory.push(isMatch);
        }

        console.log("isPasswordInHistory : "+isPasswordInHistory);
        if (isPasswordInHistory.includes(true)) {
            console.log("Reset password was failed due to wrong password");
            return res.status(400).send(`<script>alert('New Password should not be in the users password history'); window.location.href='/'</script>`);
        }
    }

    console.log("password is not in the user's password history");
    const updateLatest= await db.updatePasswordHistory(isUser, password);

    const updatePassword= await db.updateUserPassword(isUser, password);
    console.log("time to update user password   : "+updatePassword);
    var successReset = "New Password was updated successfully";
    return res.status(200).send(`<script>alert('${successReset}'); window.location.href='/'</script>`);
});

function checkPasswordRequirements(password) {
    const regexSymbol = /[$&+,:;=?@#|'<>.^*()%!-]/;
    const regexLowercase = /[a-z]/;
    const regexUppercase = /[A-Z]/;
    const regexDigit = /[0-9]/;

    if (REQUIRE_SYMBOLS && !regexSymbol.test(password)) {
        return false;
    }
    if (REQUIRE_LOWERCASE && !regexLowercase.test(password)) {
        return false;
    }
    if (REQUIRE_UPPERCASE && !regexUppercase.test(password)) {
        return false;
    }
    if (REQUIRE_DIGITS && !regexDigit.test(password)) {
        return false;
    }
    if (password.length < MIN_LENGTH || password.length > MAX_LENGTH) {
        return false;
    }

    return true;
}
module.exports = router;
