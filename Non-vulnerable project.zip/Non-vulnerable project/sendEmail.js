const nodemailer = require('nodemailer');
const crypto = require('crypto');
const {ER_NO_CONST_EXPR_IN_RANGE_OR_LIST_ERROR} = require("mysql/lib/protocol/constants/errors");
const dotenv = require('dotenv');
const {
    EMAILACCOUNT,EMAILPASSWORD
} = process.env;

// Function to generate a random string
function generateRandomString(length) {
    return crypto.randomBytes(Math.ceil(length / 2))
        .toString('hex')
        .slice(0, length);
}

// Function to compute SHA-1 hash of a string
function computeSHA1(input) {
    return crypto.createHash('sha1').update(input).digest('hex');
}

// Function to send email with generated SHA-1 hash
async function sendEmailWithSHA1(email) {
    // Generate random string
    const randomString = generateRandomString(10);

    // Compute SHA-1 hash
    const sha1Hash = computeSHA1(randomString);

    console.log(EMAILACCOUNT);
    console.log(EMAILPASSWORD);
    // Send email
    const transporter = nodemailer.createTransport({
        service: 'smtp.zoho.eu',
        port:465,
        secure:true,//ssl
        auth: {
            user:"adirnodeprojects@zohomail.com",
            pass: "Asdadir123!!"
        }
    });

    const mailOptions = {
        from: EMAILACCOUNT,
        to: email,
        subject: 'Your generated SHA-1 hash',
        text: `You have requested to reset password ,\n\n` +
            `Here is your generated SHA-1 hash: ${sha1Hash}`
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log('Email sent: ' + info.response);
    } catch (error) {
        console.error('Error sending email:', error);
    }
}

// Example usage
const userEmail = 'adiramr12@gmail.com';
const emailsent =  sendEmailWithSHA1(userEmail);
console.log(emailsent)
module.exports = { sendEmailWithSHA1};