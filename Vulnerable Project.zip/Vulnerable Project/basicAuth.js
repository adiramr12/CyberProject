const jwt= require('jsonwebtoken');

const authAdmin = async (req,res,next)=>{
    const jwtCookie = req.cookies.jwt;
    if (!jwtCookie) {
        console.log('JWT Token not found in cookie.');
        return res.status(401).send(`<script>alert('Access Denied'); window.location.href='/'</script>`);
    }

    const decodedToken = jwt.decode(jwtCookie);
    const role = decodedToken.role;

    console.log("role : "+role);
    // Check if the role is admin
    if (role !== 'admin') {
        return res.status(403).send(`<script>alert('Access Denied'); window.location.href='/'</script>`);
    }
    // If the role is admin, continue to the next middleware or route handler
    next();
}
const authUser = async (req,res,next)=>{
    const jwtCookie = req.cookies.jwt;
    console.log(jwtCookie);
    console.log("authUser enetering");
    if (!jwtCookie) {
        console.log('JWT Token not found in cookie.');
        return res.status(401).send(`<script>alert('Please login in order to change your password'); window.location.href='/login'</script>`);
    }

    const decodedToken = jwt.decode(jwtCookie);
    const role = decodedToken.role;


    // Check if the role is user
    if (role !== 'user') {
        return res.status(401).send(`<script>alert('You have to login in order to reset password'); window.location.href='/'</script>`);
    }
    // If the role is admin, continue to the next middleware or route handler
    next();
}

const authToken = async (req,res,next)=>{
    const tokenSHA1 = req.cookies.tokenSHA1;
    const jwtt = req.cookies.jwt;
    console.log(jwtt);
    console.log("authUser enetering");
    console.log(tokenSHA1);
    if (!jwtt) {
        console.log('JWT Token not found in cookie.');
        return res.status(401).send(`<script>alert('Please go to forgot password'); window.location.href='/login'</script>`);
    }
    if (!tokenSHA1) {
        console.log('No generate Token');
        return res.status(401).send(`<script>alert('Please go to forgot password'); window.location.href='/forgotPassword'</script>`);

    }
    req.authCookies = req.cookies;
    next();
}
module.exports= {authAdmin,authUser,authToken}