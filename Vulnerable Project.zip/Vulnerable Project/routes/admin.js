const express = require('express');
const db = require("../databse");
const auth =require("../basicAuth");
const escapeHtml = require("escape-html");
const router = express.Router();

/* GET home page. */
router.get('/',auth.authAdmin,function(req, res, next) {
    res.sendFile(__dirname + '/admin.html');
});

router.post('/', async  (   req, res) => {
    const { username, email,password } = req.body;

    const isUser = await db.findUserByUsernameOrEmail(username, email);

    console.log("User finding result : "+isUser);
    if(isUser) {
        console.log("User already exists");
        var userExistsMessage = ("Username or email are incorrect");
        return res.status(400).send(`<script>alert('${userExistsMessage}'); window.location.href='/admin'</script>`);
    }

    const User= await db.createUser(username, email, password);
    console.log("User was created");
    console.log(User);
    console.log("SQLINJECT");
    const findUser= await db.findUser(username);
    console.log(username);
    console.log("findUser : "+findUser);
    const stringFU= findUser.toString();
    const htmlResponse = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success</title>
  </head>
  <body>
    <div>
      <p>${stringFU}</p>
    </div>
    <div>
      <p>user is ${username}</p>
    </div>
    <script>
      // Optional: Redirect to the home page after a delay
      setTimeout(() => {
        window.location.href = '/';
      }, 3000); // Redirect after 3 seconds (adjust as needed)
    </script>
  </body>
  </html>
`;

    return res.status(200).send(`<script>alert(\`${htmlResponse}\`);</script>`);


});

function checkPasswordRequirements(password) {
    const regexSymbol = /[$&+,:;=?@#|'<>.^*()%!-]/;
    const regexLowercase = /[a-z]/;
    const regexUppercase = /[A-Z]/;
    const regexDigit = /[0-9]/;

    if (REQUIRE_SYMBOLS && !regexSymbol.test(password)) {
        return false;
    }
    if (REQUIRE_LOWERCASE && !regexLowercase.test(password)) {
        return false;
    }
    if (REQUIRE_UPPERCASE && !regexUppercase.test(password)) {
        return false;
    }
    if (REQUIRE_DIGITS && !regexDigit.test(password)) {
        return false;
    }
    if (password.length < MIN_LENGTH || password.length > MAX_LENGTH) {
        return false;
    }

    return true;
}

module.exports = router;
