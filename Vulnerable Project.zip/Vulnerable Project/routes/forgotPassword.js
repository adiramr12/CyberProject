const express = require('express');
const router = express.Router();
const db = require("../databse");
const dotenv = require('dotenv');
const jwt = require("jsonwebtoken");

const crypto = require('crypto');

const {
    JWT_SECRET,
    JWTEXPIRESIN

} = process.env;

router.get('/', (req, res) => {
    res.sendFile(__dirname + '/forgotPassword.html');
});

router.post('/', async (req, res) => {
    const {username} = req.body;
    const findUser = await db.findUserByUsernameOrEmail(username, null);
    console.log("User finding result : "+findUser);

    const generateRandomString = (length) => {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let randomString = '';
        for (let i = 0; i < length; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            randomString += characters.charAt(randomIndex);
        }
        return randomString;
    };

// Function to create a SHA-1 hash for a given string
    const createSHA1Hash = (data) => {
        const sha1 = crypto.createHash('sha1');
        sha1.update(data);
        return sha1.digest('hex');
    };
    const randomString = generateRandomString(16); // Adjust the length as needed
    const sha1Token = createSHA1Hash(randomString);
    console.log("asdasdasdasda",sha1Token);
    const token = jwt.sign({ username: username , role:'userToken'}, JWT_SECRET,{expiresIn: JWTEXPIRESIN});
    const creationMessage = ("Token is : "+sha1Token);
    res.cookie('jwt', token, { httpOnly: true, maxAge: 30 * 1000 });
    res.cookie('tokenSHA1', sha1Token, { httpOnly: true, maxAge: 30 * 1000 });
    return res.status(200).send(`<script>alert('${creationMessage} '); window.location.href='/userToken'</script>`);



});

module.exports = router;