const express = require('express');
const auth = require('../basicAuth');

const router = express.Router();

/* GET home page. */
router.get('/',function(req, res, next) {
  res.sendFile(__dirname + '/index.html');
});

router.post('/', async (req, res) => {
  // Handle login logic
});


module.exports = router;
