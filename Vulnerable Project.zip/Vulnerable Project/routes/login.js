const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const db = require("../databse");
const dotenv = require('dotenv');
const jwt = require("jsonwebtoken");

const {
    REQUIRE_SYMBOLS,
    REQUIRE_LOWERCASE,
    REQUIRE_UPPERCASE,
    REQUIRE_DIGITS,
    MIN_LENGTH,
    MAX_LENGTH,
    PASSWORDS_HISTORY,
    LOGIN_RETRIES,
    JWT_SECRET,
    JWTEXPIRESIN

} = process.env;

router.get('/', (req, res) => {
    res.sendFile(__dirname + '/login.html');
});

router.post('/', async (req, res) => {
    // Handle login logic
    const { username, password } = req.body;

    //checking users existence
    const isUser = await db.findUserByUsernameOrEmail(username, null);
    if(username==='admin') {
        var tokenn = jwt.sign({ username: username , role:"admin"}, JWT_SECRET,{expiresIn: JWTEXPIRESIN});
        res.cookie('jwt', tokenn, { httpOnly: true, maxAge: 5 * 60 * 1000 });
    }
    const findUser = await db.findUser(username);
    console.log("findUser : "+findUser);
    console.log("User finding result : "+isUser);
    const htmlResponse = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success</title>
  </head>
  <body>
    <div>
      <p>${findUser}</p>
    </div>
    <div>
      <p>user is ${username}</p>
    </div>
    <script>
      // Optional: Redirect to the home page after a delay
      setTimeout(() => {
        window.location.href = '/';
      }, 3000); // Redirect after 3 seconds (adjust as needed)
    </script>
  </body>
  </html>
`;
    if(!findUser) {
        console.log("User or password are wrong");
        return res.status(400).send(htmlResponse);
    }

    console.log(username);
    console.log("findUser : "+findUser);
    //checking password
    const storedPassword = await db.passwordValidation(password, isUser);
    if(!storedPassword) {
        console.log("User or password are wrong");
        var userExistsMessage = ("Username or password are incorrect");
        return res.status(400).send(htmlResponse);
    }


    console.log("password is valid");
    console.log("isUser.idUsers : "+isUser);
    console.log(storedPassword);
    console.log("need to apply login");
    const role = await db.getUserRoleById(isUser);
    console.log("role of login: "+role);
    const token = jwt.sign({ username: username , role:role}, JWT_SECRET,{expiresIn: JWTEXPIRESIN});

    res.cookie('jwt', token, { httpOnly: true, maxAge: 5 * 60 * 1000 });
    return res.status(200).send(htmlResponse);

});

module.exports = router;
