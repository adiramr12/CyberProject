const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const db =require('../databse');
const dotenv = require('dotenv');
const jwt = require('jsonwebtoken');
const escapeHtml = require('escape-html');


const {
    REQUIRE_SYMBOLS,
    REQUIRE_LOWERCASE,
    REQUIRE_UPPERCASE,
    REQUIRE_DIGITS,
    MIN_LENGTH,
    MAX_LENGTH,
    JWT_SECRET,
    JWTEXPIRESIN
} = process.env;


router.get('/', (req, res) => {
    res.sendFile(__dirname + '/signup.html');
});

router.post('/', async (req, res) => {
    console.log("enterting signup post");
    const { username, password, email } = req.body;

    //checking users existence
    const isUser = await db.findUserByUsernameOrEmail(username, email);
    const findUser = await db.findUser(username);
    const htmlResponse = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success</title>
  </head>
  <body>
    <div>
      <p>${findUser}</p>
    </div>
    <div>
      <p>user is ${username}</p>
    </div>
    <script>
      // Optional: Redirect to the home page after a delay
      setTimeout(() => {
        window.location.href = '/';
      }, 2000); // Redirect after 3 seconds (adjust as needed)
    </script>
  </body>
  </html>
`;
    console.log("User finding result : "+findUser);
    if(findUser!==false) {
        console.log("user already exists");
        var userExistsMessage = ("Username or email already exists");
        return res.status(400).send(htmlResponse);
    }

    // checking password requirements
    const isPasswordValid = checkPasswordRequirements(password);
    if(!isPasswordValid) {
        var requirementsMessage=("Password should meet the following requirements:\\n"+
            "Include at least one symbol, one lowercase, one uppercase, one digit and length between " + `${MIN_LENGTH} and ${MAX_LENGTH}` )
        return res.status(400).send(htmlResponse);

    }
    console.log("password is valid");
    console.log(isPasswordValid);
    const result = await db.createUser(username, email, password);
    console.log(result);
    console.log("user created!!!");
    var creationMessage = ("User created successfully");

    const token = jwt.sign({ username: username , role:"user"}, JWT_SECRET,{expiresIn: JWTEXPIRESIN});

    res.cookie('jwt', token, { httpOnly: true, maxAge: 5 * 60 * 1000 });
    return res.status(200).send(htmlResponse);
});

function checkPasswordRequirements(password) {
    const regexSymbol = /[$&+,:;=?@#|'<>.^*()%!-]/;
    const regexLowercase = /[a-z]/;
    const regexUppercase = /[A-Z]/;
    const regexDigit = /[0-9]/;

    if (REQUIRE_SYMBOLS && !regexSymbol.test(password)) {
        return false;
    }
    if (REQUIRE_LOWERCASE && !regexLowercase.test(password)) {
        return false;
    }
    if (REQUIRE_UPPERCASE && !regexUppercase.test(password)) {
        return false;
    }
    if (REQUIRE_DIGITS && !regexDigit.test(password)) {
        return false;
    }
    if (password.length < MIN_LENGTH || password.length > MAX_LENGTH) {
        return false;
    }

    return true;
}

module.exports = router;
