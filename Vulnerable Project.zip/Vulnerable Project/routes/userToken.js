const express = require('express');
const router = express.Router();
const db = require("../databse");
const dotenv = require('dotenv');
const jwt = require("jsonwebtoken");
const auth = require("../basicAuth");

const {
    JWT_SECRET,
    JWTEXPIRESIN

} = process.env;


router.get('/',auth.authToken,function(req, res, next) {
    res.sendFile(__dirname + '/userToken.html');
});
router.post('/',async (req, res) => {
    const {username,tokeninput} = req.body;
    const cookies = req.authCookies;
    console.log("cookies : "+req.authCookies);
    if(!username || !tokeninput){
        return res.status(200).send(`<script>alert('Must have User and Token'); window.location.href='/userToken'</script>`);
    }

    if(!(tokeninput===req.cookie.tokenSHA1 && username===req.cookie.username)){
        return res.status(200).send(`<script>alert('Failed verification'); window.location.href='/forgotPassword'</script>`);
    }

    const idUser=await db.findUserByUsernameOrEmail(username);
    const updatePassword=await db.updateUserPassword(idUser,"123qwe!@#QWE");
    return res.status(200).send(`<script>alert('Password updated to 123qwe!@#QWE Go login before you continue.'); window.location.href='/'</script>`);

});

module.exports = router;